
import java.util.*;

public class killandmove{
    static int cnt = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        cnt = 0;
        int size = 9;
        int[][] chessboard = new int[size][size];

        System.out.print("Enter number of soldiers: ");
        int soldierCount = Integer.parseInt(scanner.nextLine());

       
        for (int i = 1; i <= soldierCount; i++) {
            System.out.print("Enter coordinates");
            String[] coords = scanner.nextLine().split(",");
            int x = Integer.parseInt(coords[0]) - 1; 
            int y = Integer.parseInt(coords[1]) - 1; 
            
            if (x >= 0 && x < size && y >= 0 && y < size) {
                chessboard[y][x] = 1; 
            } else {
                System.out.println("Invalid coordinates. Please enter values between 1 and " + size);
                i--; 
            }
        }


        System.out.print("Enter the coordinates special castle: ");
        String[] coords = scanner.nextLine().split(",");
        int startX = Integer.parseInt(coords[0]) - 1; 
        int startY = Integer.parseInt(coords[1]) - 1;

        int[][] vis = new int[size][size];

        List<int[]> initialPath = new ArrayList<>();
        initialPath.add(new int[]{startX, startY});
        solve(chessboard, vis, startY, startX, startY, startX, 'd', 0);

        System.out.println("Total unique paths: " + cnt);
        scanner.close();
    }

  

    static void solve(int[][] mat, int[][] vis, int row, int col, int r, int c, char dir, int pathLength) {
        int size = mat.length;

        if (row < 0 || col < 0 || row >= size || col >= size) {
            return;
        }

        
        if (row == r && col == c && pathLength > 0) {
            cnt++;
            return;
        }

        if (mat[row][col] == 1) {
            if (vis[row][col] != 1) {
                vis[row][col] = 1; 

               
                switch (dir) {
                    case 'd': 
                        solve(mat, vis, row, col + 1, r, c, 'r', pathLength + 1); 
                        break;
                    case 'r': 
                        solve(mat, vis, row - 1, col, r, c, 'u', pathLength + 1); 
                        break;
                    case 'u': 
                        solve(mat, vis, row, col - 1, r, c, 'l', pathLength + 1); 
                        break;
                    case 'l': 
                        solve(mat, vis, row + 1, col, r, c, 'd', pathLength + 1); 
                        break;
                }

               
                vis[row][col] = 0;
            }

            
            switch (dir) {
                case 'd':
                    solve(mat, vis, row + 1, col, r, c, dir, pathLength);
                    break;
                case 'r':
                    solve(mat, vis, row, col + 1, r, c, dir, pathLength); 
                    break;
                case 'u':
                    solve(mat, vis, row - 1, col, r, c, dir, pathLength); 
                    break;
                case 'l':
                    solve(mat, vis, row, col - 1, r, c, dir, pathLength); 
                    break;
            }
        } else {
            switch (dir) {
                case 'd':
                    solve(mat, vis, row + 1, col, r, c, dir, pathLength); 
                    break;
                case 'r':
                    solve(mat, vis, row, col + 1, r, c, dir, pathLength); 
                    break;
                case 'u':
                    solve(mat, vis, row - 1, col, r, c, dir, pathLength);
                    break;
                case 'l':
                    solve(mat, vis, row, col - 1, r, c, dir, pathLength); 
                    break;
            }
        }
    }

 
}
