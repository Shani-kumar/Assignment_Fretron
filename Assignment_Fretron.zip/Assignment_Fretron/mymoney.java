

import java.util.*;

class mymoney {
    static class Person {
        String name;
        List<Integer> allocatedWeights;
        int targetWeight;
        int currentWeight;

        Person(String name, int targetWeight) {
            this.name = name;
            this.allocatedWeights = new ArrayList<>();
            this.targetWeight = targetWeight;
            this.currentWeight = 0;
        }

        void addWeight(int weight) {
            allocatedWeights.add(weight);
            currentWeight += weight;
        }

        void removeWeight(int weight) {
            allocatedWeights.remove(Integer.valueOf(weight));
            currentWeight -= weight;
        }

        @Override
        public String toString() {
            return name + ": " + allocatedWeights + " (Total: " + currentWeight + "g)";
        }
    }

    static List<List<Integer>> optimalAllocation = new ArrayList<>();
    static int minimumDifference = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> fruitWeights = new ArrayList<>();

        System.out.println("Enter fruit weights in grams (-1 to stop): ");
        while (true) {
            int weight = scanner.nextInt();
            if (weight == -1) {
                break;
            }
            fruitWeights.add(weight);
        }

        int totalAmount = 100; 
        int paymentA = 50;
        int paymentB = 30;
        int paymentC = 20;

        int totalWeight = fruitWeights.stream().mapToInt(Integer::intValue).sum();
        Person personA = new Person("A", (paymentA * totalWeight) / totalAmount);
        Person personB = new Person("B", (paymentB * totalWeight) / totalAmount);
        Person personC = new Person("C", (paymentC * totalWeight) / totalAmount);

        distributeFruits(fruitWeights, 0, personA, personB, personC);

        System.out.println("Optimal Allocation Result:");
        System.out.println("A: " + optimalAllocation.get(0));
        System.out.println("B: " + optimalAllocation.get(1));
        System.out.println("C: " + optimalAllocation.get(2));
    }

    static void distributeFruits(List<Integer> fruitWeights, int index, Person personA, Person personB, Person personC) {
        if (index == fruitWeights.size()) {
            int totalWeightAllocated = personA.currentWeight + personB.currentWeight + personC.currentWeight;
            int difference = Math.abs(totalWeightAllocated - (personA.targetWeight + personB.targetWeight + personC.targetWeight));
            
            if (difference < minimumDifference) {
                minimumDifference = difference;
                optimalAllocation.clear();
                optimalAllocation.add(new ArrayList<>(personA.allocatedWeights));
                optimalAllocation.add(new ArrayList<>(personB.allocatedWeights));
                optimalAllocation.add(new ArrayList<>(personC.allocatedWeights));
            }
            return;
        }

        int weight = fruitWeights.get(index);

        if (personA.currentWeight + weight <= personA.targetWeight) {
            personA.addWeight(weight);
            distributeFruits(fruitWeights, index + 1, personA, personB, personC);
            personA.removeWeight(weight);
        }

        if (personB.currentWeight + weight <= personB.targetWeight) {
            personB.addWeight(weight);
            distributeFruits(fruitWeights, index + 1, personA, personB, personC);
            personB.removeWeight(weight);
        }

        if (personC.currentWeight + weight <= personC.targetWeight) {
            personC.addWeight(weight);
            distributeFruits(fruitWeights, index + 1, personA, personB, personC);
            personC.removeWeight(weight);
        }

        distributeFruits(fruitWeights, index + 1, personA, personB, personC);
    }
}
